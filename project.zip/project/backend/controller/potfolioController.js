const Portfolio = require('../models/portfolioModel');
const AssetService = require('../services/assetService');

exports.getPortfolio = async (req, res) => {
    try {
        const userId = req.user.id;
        const portfolio = await Portfolio.findOne({ where: { userId } });
        if (!portfolio) {
            return res.status(404).json({ error: 'Portfolio not found' });
        }

        const portfolioValue = await AssetService.calculatePortfolioValue(portfolio.assets);
        res.json({ portfolio, portfolioValue });
    } catch (error) {
        res.status(500).json({ error: 'Could not fetch portfolio' });
    }
};

exports.updatePortfolio = async (req, res) => {
    try {
        const userId = req.user.id;
        const { assets } = req.body;
        const portfolio = await Portfolio.findOne({ where: { userId } });

        if (!portfolio) {
            return res.status(404).json({ error: 'Portfolio not found' });
        }

        portfolio.assets = assets;
        await portfolio.save();
        res.json(portfolio);
    } catch (error) {
        res.status(500).json({ error: 'Could not update portfolio' });
    }
};