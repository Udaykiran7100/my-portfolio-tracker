const Transaction = require('../models/transactionModel');
const Portfolio = require('../models/portfolioModel');

exports.createTransaction = async (req, res) => {
    try {
        const userId = req.user.id;
        const { assetSymbol, quantity, price } = req.body;
        
        const transaction = await Transaction.create({ userId, assetSymbol, quantity, price });
        const portfolio = await Portfolio.findOne({ where: { userId } });

        if (portfolio) {
            portfolio.assets.push({ assetSymbol, quantity, price });
            await portfolio.save();
        }

        res.status(201).json(transaction);
    } catch (error) {
        res.status(500).json({ error: 'Transaction creation failed' });
    }
};

exports.getTransactions = async (req, res) => {
    try {
        const userId = req.user.id;
        const transactions = await Transaction.findAll({ where: { userId } });
        res.json(transactions);
    } catch (error) {
        res.status(500).json({ error: 'Could not fetch transactions' });
    }
};