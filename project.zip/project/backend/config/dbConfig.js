const { Sequelize } = require('sequelize');

const sequelize = new Sequelize(process.env.DB_URL || 'postgres://user:pass@localhost:5432/portfolio');

module.exports = sequelize;