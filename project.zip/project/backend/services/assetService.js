const axios = require('axios');

exports.calculatePortfolioValue = async (assets) => {
    let totalValue = 0;
    for (const asset of assets) {
        const { assetSymbol, quantity, price } = asset;
        const currentPrice = await this.getAssetPrice(assetSymbol);
        totalValue += currentPrice * quantity;
    }
    return totalValue;
};

exports.getAssetPrice = async (symbol) => {
    try {
        const response = await axios.get(https://api.coingecko.com/api/v3/simple/price?ids=${symbol}&vs_currencies=usd);
        return response.data[symbol].usd;
    } catch (error) {
        throw new Error('Failed to fetch asset price');
    }
};