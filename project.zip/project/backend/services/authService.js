const jwt = require('jsonwebtoken');
const User = require('../models/userModel');

exports.authenticate = async (token) => {
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const user = await User.findByPk(decoded.id);
        if (!user) throw new Error('User not found');
        return user;
    } catch (error) {
        throw new Error('Authentication failed');
    }
};