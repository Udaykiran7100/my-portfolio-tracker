const express = require('express');
const bodyParser = require('body-parser');
const sequelize = require('./config/dbConfig');
const authRoutes = require('./routes/authRoutes');
const portfolioRoutes = require('./routes/portfolioRoutes');
const transactionRoutes = require('./routes/transactionRoutes');

const app = express();
app.use(bodyParser.json());

app.use('/auth', authRoutes);
app.use('/portfolio', portfolioRoutes);
app.use('/transactions', transactionRoutes);

sequelize.sync().then(() => {
    app.listen(5000, () => {
        console.log('Server running on port 5000');
    });
});