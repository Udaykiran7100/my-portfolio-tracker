const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/dbConfig');

const Portfolio = sequelize.define('Portfolio', {
    userId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        unique: true
    },
    assets: {
        type: DataTypes.JSONB,  // Stores an array of assets
        allowNull: true
    }
});

module.exports = Portfolio;